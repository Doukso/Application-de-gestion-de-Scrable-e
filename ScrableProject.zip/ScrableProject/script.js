let players = [];
let currentPlayerIndex = 0;
let turnCount = 1; // Ajout d'un compteur de tours

// Initialisation du plateau
function createBoard() {
  const board = document.getElementById('board');
  board.innerHTML = ''; // Effacer le plateau s'il existe déjà
  for (let i = 0; i < 225; i++) {
    let cell = document.createElement('div');
    cell.classList.add('cell');
    board.appendChild(cell);
  }
}

// Ajouter un joueur
function addPlayer() {
  const playerName = document.getElementById('playerName').value.trim(); // Supprimer les espaces inutiles
  if (playerName) {
    players.push({ name: playerName, score: 0 });
    document.getElementById('playerName').value = ''; // Réinitialiser le champ après ajout
    updatePlayerList();
    updateScoreList();
    updateCurrentPlayer();
  } else {
    alert("Veuillez entrer un nom de joueur.");
  }
}

// Mettre à jour la liste des joueurs
function updatePlayerList() {
  const playerList = document.getElementById('playerList');
  playerList.innerHTML = ''; // Vider la liste avant de la remplir
  players.forEach((player) => {
    const listItem = document.createElement('li');
    listItem.innerText = player.name;
    playerList.appendChild(listItem);
  });
}

// Mettre à jour les scores
function updateScoreList() {
  const scoreList = document.getElementById('scoreList');
  scoreList.innerHTML = ''; // Vider la liste des scores
  players.forEach((player) => {
    const scoreItem = document.createElement('li');
    scoreItem.innerText = `${player.name}: ${player.score} points`;
    scoreList.appendChild(scoreItem);
  });
}

// Mettre à jour le joueur actuel (avec changement de phrase)
function updateCurrentPlayer() {
  const currentPlayerDiv = document.getElementById('currentPlayer');
  
  // Vérifier s'il y a des joueurs avant de mettre à jour
  if (players.length > 0) {
    currentPlayerDiv.innerText = `Tour ${turnCount}: ${players[currentPlayerIndex].name} doit jouer`;
    turnCount++;  // Incrémenter le nombre de tours
  } else {
    currentPlayerDiv.innerText = "Ajoutez des joueurs pour commencer.";
  }
}

// Soumettre un mot et calculer le score
function submitWord() {
  const word = document.getElementById('wordInput').value.trim(); // Enlever les espaces autour du mot
  if (word && players.length > 0) {
    const score = calculateScore(word);
    players[currentPlayerIndex].score += score;
    updateScoreList();
    nextPlayer(); // Passer au joueur suivant
    document.getElementById('wordInput').value = ''; // Réinitialiser le champ
  } else if (!word) {
    alert("Veuillez entrer un mot.");
  } else {
    alert("Ajoutez au moins un joueur avant de soumettre un mot.");
  }
}

// Calculer le score d'un mot (simple : 1 point par lettre)
function calculateScore(word) {
  return word.length; // 1 point par lettre, peut être modifié pour un calcul plus complexe
}

// Passer au joueur suivant
function nextPlayer() {
  if (players.length > 0) {
    currentPlayerIndex = (currentPlayerIndex + 1) % players.length; // Revenir au premier joueur après le dernier
    updateCurrentPlayer();
  }
}

// Réinitialiser le jeu
function resetGame() {
  players = [];
  currentPlayerIndex = 0;
  turnCount = 1; // Remettre le compteur de tours à 1
  updatePlayerList();
  updateScoreList();
  updateCurrentPlayer();
  createBoard(); // Remettre le plateau à zéro si nécessaire
}

// Initialiser le plateau et les joueurs dès le chargement de la page
window.onload = function() {
  createBoard();
};
